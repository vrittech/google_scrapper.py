import backend.scrapers
from botasaurus_server.run import run

if __name__ == "__main__":
    run()
