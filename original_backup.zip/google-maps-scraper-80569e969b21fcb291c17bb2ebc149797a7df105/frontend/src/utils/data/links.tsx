const Links = {
  home: '/',
  output: '/output',
  about: '/about',
  api: '/api',
  notFound: '/404',
}
export default Links
