export default function ContentWrapper({ children }: any) {
  return <main className="page-content overflow-y-auto">{children}</main>
}
